self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "c89a6a2ef4b1c57cdd04ba079eaf1b28",
    "url": "/magluie/magluie.github.io/mappingpd/index.html"
  },
  {
    "revision": "4deb6b6d03add27a7761",
    "url": "/magluie/magluie.github.io/mappingpd/static/css/2.6df4c8f8.chunk.css"
  },
  {
    "revision": "949386c9e1bd600437a8",
    "url": "/magluie/magluie.github.io/mappingpd/static/css/main.bfd836fd.chunk.css"
  },
  {
    "revision": "4deb6b6d03add27a7761",
    "url": "/magluie/magluie.github.io/mappingpd/static/js/2.fb8e2a6e.chunk.js"
  },
  {
    "revision": "254c01d1a3c7d8124adf4c35e46b76e3",
    "url": "/magluie/magluie.github.io/mappingpd/static/js/2.fb8e2a6e.chunk.js.LICENSE.txt"
  },
  {
    "revision": "949386c9e1bd600437a8",
    "url": "/magluie/magluie.github.io/mappingpd/static/js/main.8664dec1.chunk.js"
  },
  {
    "revision": "21beae7c21f181d70209",
    "url": "/magluie/magluie.github.io/mappingpd/static/js/runtime-main.15b45249.js"
  },
  {
    "revision": "6b25f38ea3568441d2863b79ddc26aaa",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/1.6b25f38e.jpg"
  },
  {
    "revision": "64919ba833029590e97e04fc7c6e1888",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/2.64919ba8.jpg"
  },
  {
    "revision": "4826c9224957b632e617c2a23012ce4e",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/3.4826c922.jpg"
  },
  {
    "revision": "80c23ac90ede919fcfd6a5dc3ca477a2",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/4.80c23ac9.jpg"
  },
  {
    "revision": "070493af5a78754a81fb1e2b1a868fe7",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/5.070493af.jpg"
  },
  {
    "revision": "abf7700273c6bf539a054aaa32d58280",
    "url": "/magluie/magluie.github.io/mappingpd/static/media/6.abf77002.jpg"
  }
]);